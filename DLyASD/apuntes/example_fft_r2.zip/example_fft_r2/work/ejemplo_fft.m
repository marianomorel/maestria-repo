clear all;

n = 0:1:15;

re_x = 500 + 1000*cos(2*pi*n/16) - 850*cos(2*pi*n*2/16);
im_x = 300 +  700*cos(2*pi*n/16) - 600*cos(2*pi*n*2/16);

x = re_x + i*im_x;

y = fft(x);

re_y = real(y)
im_y = imag(y)
